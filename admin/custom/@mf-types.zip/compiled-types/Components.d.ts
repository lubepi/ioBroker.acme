import AcmeComponent from './AcmeComponent';
declare const _default: {
    AcmeComponent: typeof AcmeComponent;
};
export default _default;
